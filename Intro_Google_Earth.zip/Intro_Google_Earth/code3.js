// Define a FeatureCollection: regions of the American West.
var regions = ee.FeatureCollection([
  ee.Feature(    // Austin.
    ee.Geometry.Rectangle(-97.77, 30.38, -97.66, 30.17), {label: 'Austin'}),
  ee.Feature(  // Rural East of Austin.
    ee.Geometry.Rectangle(-97.53, 30.38, -97.42, 30.17), {label: 'Rural East'}),
 ]);

 Map.addLayer(regions, {}, 'default display');
 Map.addLayer(regions, {color: 'FF0000'}, 'colored')

// Load Landsat 8 brightness temperature data for 1 year.
var temps2015 = ee.ImageCollection('LANDSAT/LC8_L1T_32DAY_TOA')
    .filterDate('2015-01-01', '2015-12-31')
    .select('B11');

// Create a time series chart.
var tempTimeSeries = ui.Chart.image.seriesByRegion(
    temps2015, regions, ee.Reducer.mean(), 'B11', 200, 'system:time_start', 'label')
        .setChartType('ScatterChart')
        .setOptions({
          title: 'Temperature over time in regions of the American West',
          vAxis: {title: 'Temperature (Kelvin)'},
          lineWidth: 1,
          pointSize: 4,
          series: {
            0: {color: 'FF0000'}, // Austin
            1: {color: '00FF00'}, // Rural East
}});

// Display.
print(tempTimeSeries);
    