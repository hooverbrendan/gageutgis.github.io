// Load a Landsat 8 collection for a single path-row.
var collection = ee.ImageCollection('LANDSAT/LC8_L1T_TOA')
  .filter(ee.Filter.eq('WRS_PATH', 174))
  .filter(ee.Filter.eq('WRS_ROW', 75));

// Sort by cloud-cover
var image = ee.Image(collection.sort('CLOUD_COVER').first());
print('Least cloudy image: ', image);

// Load least-cloudy image
var image = ee.Image('LANDSAT/LC8_L1T_TOA/LC81740752013105LGN01');

// Define the visualization parameters.
var vizParams = {
  bands: ['B4', 'B3', 'B2'],
  min: 0,
  max: 0.5,
  gamma: [0.95, 1.1, 1]
};

// Display least-cloudy image based upon set visualization parameters. 
Map.addLayer(image, vizParams);


var burn = ee.ImageCollection('MODIS/051/MCD45A1')
  .filterDate('2011-01-01', '2011-12-31');

Map.addLayer(burn);
