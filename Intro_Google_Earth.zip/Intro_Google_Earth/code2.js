// Load a Landsat 8 collection for a single path-row.
var collection = ee.ImageCollection('LANDSAT/LC8_L1T_TOA')
  .filter(ee.Filter.eq('WRS_PATH', 27))
  .filter(ee.Filter.eq('WRS_ROW', 39));

// Sort by cloud-cover
var image = ee.Image(collection.sort('CLOUD_COVER').first());
print('Least cloudy image: ', image);

var bands = ['B2', 'B3', 'B4', 'B5'];

// Load least-cloudy image
var image = ee.Image('LANDSAT/LC8_L1T_TOA/LC80270392014118LGN00').select(bands);

// Define the visualization parameters.
var vizParams = {
  bands: ['B5', 'B4', 'B3'],
  min: 0,
  max: 0.5,
  gamma: [0.95, 1.1, 1]
};

// Display least-cloudy image based upon set visualization parameters. 
Map.addLayer(image, vizParams);

// Calculate NDVI on image and display using colorBrewer palette
var ndvi = image.normalizedDifference(['B5','B4']);
var ndviViz = {min: 0, max: 0.6, palette: ['#d73027','#f46d43','#fdae61','#fee08b','#ffffbf','#d9ef8b','#a6d96a','#66bd63','#1a9850']};
Map.addLayer(ndvi, ndviViz);

// Clip to 20000 meter buffer around city center
var roi = ee.Geometry.Point([-97.73, 30.31]).buffer(50000);
var roiViz = {min: 0, max: 0.6, palette: ['#d73027','#f46d43','#fdae61','#fee08b','#ffffbf','#d9ef8b','#a6d96a','#66bd63','#1a9850']};
Map.addLayer(ndvi.clip(roi), roiViz);



Export.image.toDrive({
 image: image,
 description: 'imageToDriveExample',
 scale: 30,
 region:geometry});

var saviiViz = {min: -1, max: 1, palette: ['#d73027','#f46d43','#fdae61','#fee08b','#ffffbf','#d9ef8b','#a6d96a','#66bd63','#1a9850']};

 Map.addLayer(savi, ndviViz);   